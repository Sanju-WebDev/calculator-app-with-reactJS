import React from 'react'

function Screen( { input } ) {
    return (
        <div className= "display-screen">
            {input}
        </div>
    )
}

export default Screen
