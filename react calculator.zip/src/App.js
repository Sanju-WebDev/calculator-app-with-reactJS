import './App.css';
import Calc from './components/calc.js'

function App() {
  return (
    <div className="App">
      <Calc />
    </div>
  );
}

export default App;
